// systemInterface.hpp

bool executeCommand( const char *cmnd );
bool timestamp( const char *fname, long *time );

