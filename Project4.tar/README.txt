This is my Make project.
It runs perfectly and it prints out the line(s) of the makefile that was ran after a file(s) was touched.
To run the program:
   1. $make
   2. $touch <filename>
   3. $./make.x Makefile
If you do not touch a file, a message saying all files are up to date will print
- Chase Watson
